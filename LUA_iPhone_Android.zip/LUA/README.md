# LUA

Central de catálogo real da Shopee e criação de conteúdo. Sem produto inventado, sem preço inventado e sem botão de enfeite.

O que funciona sem chave:
- conta, login, senha com hash, troca de senha
- status das integrações
- telas e erros claros de “FUNÇÃO NÃO CONFIGURADA”

O que só funciona depois da chave:
- catálogo Shopee
- vídeo
- assistente de IA
- e-mail de recuperação

## 1. Instalar

Precisa de Python 3.10+ e Pillow.

```bash
cd LUA
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## 2. Configurar

Edite `.env` ou use a tela Configurações. Segredo digitado na tela fica em `data/secrets.json` (permissão 600) e não volta para o navegador.

## 3. Onde colocar cada chave

| Variável | Para quê | Onde conseguir |
|---|---|---|
| `SHOPEE_APP_ID` | catálogo e link | affiliate.shopee.com.br → Open API |
| `SHOPEE_SECRET` | assinatura da API | mesmo lugar |
| `SHOPEE_SUB_ID` | rastreio do afiliado | você escolhe, até 5 subIds |
| `OPENAI_API_KEY` | LUA, roteiro, legenda | platform.openai.com |
| `FAL_KEY` | vídeo Kling | fal.ai |
| `RUNWAY_API_KEY` | vídeo Runway | docs.dev.runwayml.com |
| `VIDEO_PROVIDER` | `fal` ou `runway` | — |
| `VIDEO_DAILY_LIMIT` | só se o painel informar um número | não invente 100 |
| `SMTP_*` | e-mail de senha | seu provedor de e-mail |
| `APP_SECRET` | sessão | troque em produção |

## 4. Shopee

Endpoint real usado: `https://open-api.affiliate.shopee.com.br/graphql`

Consulta: `productOfferV2`. Assinatura: `SHA256(AppId + Timestamp + Payload + Secret)`.

A API não envia preço anterior, descrição longa, categoria nem campo “viral”. O app mostra isso. A lista VIRAIS usa Top performance e avisa que não é viralidade.

Cadastro da API pode exigir aprovação da Shopee. Sem App ID e Secret o catálogo fica vazio de propósito.

## 5. IA

`POST https://api.openai.com/v1/chat/completions` com `OPENAI_MODEL` (padrão `gpt-4o-mini`). A chave fica no servidor.

Sem chave, legenda usa só nome, preço, desconto, vendas e loja. Não inventa benefício.

## 6. Vídeo

Camada `VIDEO_PROVIDER`:

- `fal`: `POST https://fal.run/fal-ai/kling-video/v2.1/standard/image-to-video`
- `runway`: `POST https://api.dev.runwayml.com/v1/image_to_video` com header `X-Runway-Version: 2024-11-06`

O prompt pede para não alterar forma, logo, cor e embalagem. O app avisa que o modelo não garante isso. Sem chave, nenhum arquivo de vídeo é criado.

## 7. Rodar local

```bash
python3 run.py
```

Abra `http://127.0.0.1:8787` no celular ou no computador. A barra de baixo funciona nos dois.

## 8. Publicar

É um servidor Python. Em um VPS:

1. copie a pasta
2. preencha `.env` e desligue `ALLOW_DEV_RESET_LINK`
3. rode atrás de HTTPS (Caddy ou Nginx)
4. não exponha `data/secrets.json`

Não é um app de loja. No celular, use o navegador ou “Adicionar à tela de início”. Salvar vídeo baixa o mp4; a galeria depende do sistema.

## 9. Testar

```bash
python3 tests/test_lua.py
```

O script testa conta, login, senha errada, recuperação, status, catálogo sem chave, vídeo sem chave, carrossel sem produto, assistente sem chave e bloqueio de imagem externa.

Com as chaves preenchidas, use Configurações → Testar Shopee e Testar IA. Vídeo só conta como pronto se o mp4 existir.

## 10. Erros comuns

- “FUNÇÃO NÃO CONFIGURADA”: falta chave. O nome da variável aparece na tela.
- Shopee 401 ou Invalid Signature: App ID/Secret trocados ou relógio do servidor errado.
- Vídeo falha: a foto da Shopee precisa ser uma URL pública. O modelo pode recusar a imagem.
- Microfone: o navegador precisa de permissão. Sem API de voz no aparelho, o app mostra o erro.
- Cópia: se o navegador bloquear a área de transferência, o texto continua selecionável.
