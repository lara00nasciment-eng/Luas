import json
import urllib.error
import urllib.request
from app.config import get

TIMEOUT = 40


def missing():
    return [] if get("OPENAI_API_KEY") else ["OPENAI_API_KEY"]


def chat(messages, max_tokens=700):
    key = get("OPENAI_API_KEY")
    if not key:
        raise RuntimeError("OPENAI_API_KEY não configurada")
    model = get("OPENAI_MODEL") or "gpt-4o-mini"
    body = json.dumps(
        {"model": model, "messages": messages, "temperature": 0.4, "max_tokens": max_tokens}
    ).encode()
    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as res:
            data = json.loads(res.read().decode())
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode(errors="replace")[:300]
        raise RuntimeError(f"OpenAI respondeu HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError("Verifique sua conexão. A OpenAI não respondeu.") from exc
    try:
        return data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError) as exc:
        raise RuntimeError("A OpenAI não devolveu texto.") from exc


def product_facts(product):
    lines = [
        f"Nome: {product.get('name')}",
        f"Preço mínimo: {product.get('priceMin')}",
        f"Preço máximo: {product.get('priceMax')}",
        f"Desconto informado: {product.get('discountRate')}",
        f"Vendas informadas: {product.get('sales')}",
        f"Avaliação informada: {product.get('rating')}",
        f"Loja: {product.get('shopName')}",
        f"Comissão: {product.get('commissionRate')}",
        "Não invente benefício, material, garantia, prazo ou estoque se não estiver acima.",
    ]
    return "\n".join(lines)
