import textwrap
import urllib.request
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def _font(size, bold=False):
    path = FONT if bold else FONT_REG
    try:
        return ImageFont.truetype(path, size)
    except OSError:
        return ImageFont.load_default()


def _fetch_image(url):
    req = urllib.request.Request(url, headers={"User-Agent": "LUA/1.0"})
    with urllib.request.urlopen(req, timeout=20) as res:
        return Image.open(BytesIO(res.read())).convert("RGB")


def _money(value):
    if value is None or value == "":
        return "não informado"
    try:
        return f"R$ {float(value):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except (TypeError, ValueError):
        return str(value)


def build(product, folder: Path):
    if not product.get("imageUrl"):
        raise RuntimeError("A API não enviou foto deste produto. O carrossel não foi inventado.")
    photo = _fetch_image(product["imageUrl"])
    folder.mkdir(parents=True, exist_ok=True)
    slides = [
        ("CHAMADA", product["name"], f"Preço: {_money(product.get('priceMin'))}"),
        ("O QUE A API INFORMA", f"Vendas: {product.get('sales') if product.get('sales') is not None else 'não informado'}", f"Avaliação: {product.get('rating') if product.get('rating') is not None else 'não informado'}"),
        ("PREÇO", f"De {_money(product.get('priceMin'))} a {_money(product.get('priceMax'))}", f"Desconto: {product.get('discountRate') if product.get('discountRate') not in (None, '') else 'não informado'}"),
        ("LOJA", product.get("shopName") or "não informada", "Preço anterior: a API não envia"),
        ("VER NA SHOPEE", product["name"][:80], "Abra o link real do produto"),
    ]
    files = []
    for index, (title, line1, line2) in enumerate(slides, start=1):
        canvas = Image.new("RGB", (1080, 1350), "#000000")
        draw = ImageDraw.Draw(canvas)
        thumb = photo.copy()
        thumb.thumbnail((920, 760))
        canvas.paste(thumb, ((1080 - thumb.width) // 2, 80))
        draw.text((60, 880), title, font=_font(42, True), fill="#FFD60A")
        y = 960
        for line in textwrap.wrap(line1, 28)[:3]:
            draw.text((60, y), line, font=_font(40, True), fill="#FFFFFF")
            y += 52
        for line in textwrap.wrap(line2, 34)[:2]:
            draw.text((60, y + 10), line, font=_font(32), fill="#DDDDDD")
            y += 42
        path = folder / f"slide-{index}.png"
        canvas.save(path, "PNG")
        files.append(path.name)
    return files
