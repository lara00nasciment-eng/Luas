import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
STORAGE = ROOT / "storage"
PUBLIC = ROOT / "public"
SECRETS_PATH = DATA / "secrets.json"
ENV_PATH = ROOT / ".env"

DATA.mkdir(exist_ok=True)
STORAGE.mkdir(exist_ok=True)
(STORAGE / "videos").mkdir(exist_ok=True)
(STORAGE / "carousels").mkdir(exist_ok=True)


def load_env_file():
    if not ENV_PATH.exists():
        return
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


def load_secrets():
    if not SECRETS_PATH.exists():
        return {}
    try:
        return json.loads(SECRETS_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def save_secrets(data):
    SECRETS_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        os.chmod(SECRETS_PATH, 0o600)
    except OSError:
        pass


def get(name, default=""):
    secrets = load_secrets()
    if name in secrets and str(secrets[name]).strip():
        return str(secrets[name]).strip()
    return os.environ.get(name, default).strip()


def configured(*names):
    return all(get(name) for name in names)
