import hashlib
import hmac
import json
import mimetypes
import secrets
import smtplib
import threading
import time
import traceback
import urllib.request
from email.message import EmailMessage
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from app import ai, carousel, shopee, video
from app.config import PUBLIC, ROOT, STORAGE, get, load_env_file, save_secrets, load_secrets
from app.db import connect, init_db, now

load_env_file()
init_db()
APP_SECRET = get("APP_SECRET") or "sol-dev-secret-troque"
LOGIN_ATTEMPTS = {}


def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 200_000).hex()
    return salt, digest


def make_token(user_id):
    exp = int(time.time()) + 60 * 60 * 24 * 14
    payload = f"{user_id}.{exp}"
    sig = hmac.new(APP_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}.{sig}"


def read_token(token):
    try:
        user_id, exp, sig = token.split(".")
        payload = f"{user_id}.{exp}"
        expected = hmac.new(APP_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected) or int(exp) < time.time():
            return None
        return int(user_id)
    except (ValueError, TypeError):
        return None


def not_configured(missing, where):
    return {
        "ok": False,
        "code": "NOT_CONFIGURED",
        "message": "FUNÇÃO NÃO CONFIGURADA",
        "missing": missing,
        "where": where,
    }


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        print(f"[LUA] {self.address_string()} {fmt % args}")

    def send_json(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length > 2_000_000:
            raise ValueError("Corpo grande demais")
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode() or "{}")

    def user_id(self):
        header = self.headers.get("Authorization") or ""
        if not header.startswith("Bearer "):
            return None
        return read_token(header[7:])

    def do_GET(self):
        try:
            self.route("GET")
        except BrokenPipeError:
            return
        except Exception as exc:
            traceback.print_exc()
            self.send_json(500, {"ok": False, "message": "Erro interno. Tente novamente.", "detail": str(exc)})

    def do_POST(self):
        try:
            self.route("POST")
        except Exception as exc:
            traceback.print_exc()
            self.send_json(500, {"ok": False, "message": "Erro interno. Tente novamente.", "detail": str(exc)})

    def do_DELETE(self):
        try:
            self.route("DELETE")
        except Exception as exc:
            traceback.print_exc()
            self.send_json(500, {"ok": False, "message": "Erro interno. Tente novamente.", "detail": str(exc)})

    def route(self, method):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path.startswith("/api/"):
            self.api(method, path, query)
            return
        self.static(path)

    def static(self, path):
        rel = "index.html" if path in ("/", "") else path.lstrip("/")
        file_path = (PUBLIC / rel).resolve()
        if not str(file_path).startswith(str(PUBLIC.resolve())) or not file_path.is_file():
            self.send_error(404)
            return
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(file_path.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def api(self, method, path, query):
        if path == "/api/status" and method == "GET":
            return self.send_json(200, status_payload())
        if path == "/api/auth/register" and method == "POST":
            return self.register()
        if path == "/api/auth/login" and method == "POST":
            return self.login()
        if path == "/api/auth/forgot" and method == "POST":
            return self.forgot()
        if path == "/api/auth/reset" and method == "POST":
            return self.reset_password()
        if path == "/api/auth/me" and method == "GET":
            return self.me()
        uid = self.user_id()
        if not uid:
            return self.send_json(401, {"ok": False, "message": "Entre na sua conta."})
        if path == "/api/catalog" and method == "GET":
            return self.catalog(uid, query)
        if path == "/api/catalog/refresh" and method == "POST":
            return self.refresh(uid, query)
        if path.startswith("/api/products/") and path.endswith("/link") and method == "POST":
            return self.product_link(path.split("/")[3])
        if path.startswith("/api/products/") and method == "GET":
            return self.product(path.split("/")[3])
        if path == "/api/videos" and method == "GET":
            return self.videos(uid)
        if path == "/api/videos" and method == "POST":
            return self.create_video(uid)
        if path.startswith("/api/videos/") and path.endswith("/file") and method == "GET":
            return self.video_file(uid, path.split("/")[3])
        if path.startswith("/api/videos/") and path.endswith("/regenerate") and method == "POST":
            return self.regenerate_video(uid, path.split("/")[3])
        if path.startswith("/api/videos/") and method == "GET":
            return self.one_video(uid, path.split("/")[3])
        if path.startswith("/api/videos/") and method == "DELETE":
            return self.delete_video(uid, path.split("/")[3])
        if path == "/api/carousels" and method == "GET":
            return self.carousels(uid)
        if path == "/api/carousels" and method == "POST":
            return self.create_carousel(uid)
        if "/slide/" in path and method == "GET":
            parts = path.split("/")
            return self.slide_file(uid, parts[3], parts[5])
        if path.startswith("/api/carousels/") and method == "DELETE":
            return self.delete_carousel(uid, path.split("/")[3])
        if path == "/api/posts" and method == "POST":
            return self.create_post(uid)
        if path == "/api/posts" and method == "GET":
            return self.posts(uid)
        if path == "/api/assistant" and method == "POST":
            return self.assistant(uid)
        if path == "/api/settings" and method == "GET":
            return self.send_json(200, settings_view())
        if path == "/api/settings/integrations" and method == "POST":
            return self.save_integrations()
        if path == "/api/settings/test/shopee" and method == "POST":
            return self.test_shopee()
        if path == "/api/settings/test/ai" and method == "POST":
            return self.test_ai()
        if path == "/api/limits" and method == "GET":
            return self.send_json(200, limits_for(uid))
        if path.startswith("/api/image") and method == "GET":
            return self.proxy_image(query)
        return self.send_json(404, {"ok": False, "message": "Rota não encontrada."})

    def register(self):
        data = self.read_json()
        email = (data.get("email") or "").strip().lower()
        password = data.get("password") or ""
        if "@" not in email or len(password) < 8:
            return self.send_json(400, {"ok": False, "message": "Use um e-mail válido e senha com 8 ou mais caracteres."})
        salt, digest = hash_password(password)
        conn = connect()
        try:
            conn.execute(
                "INSERT INTO users (email, password_hash, salt, created_at) VALUES (?, ?, ?, ?)",
                (email, digest, salt, now()),
            )
            conn.commit()
            user_id = conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()["id"]
        except Exception:
            return self.send_json(409, {"ok": False, "message": "Este e-mail já tem conta."})
        finally:
            conn.close()
        self.send_json(200, {"ok": True, "token": make_token(user_id), "email": email})

    def login(self):
        ip = self.client_address[0]
        bucket = LOGIN_ATTEMPTS.setdefault(ip, [])
        recent = [t for t in bucket if t > time.time() - 900]
        LOGIN_ATTEMPTS[ip] = recent
        if len(recent) >= 10:
            return self.send_json(429, {"ok": False, "message": "Muitas tentativas. Espere 15 minutos."})
        data = self.read_json()
        email = (data.get("email") or "").strip().lower()
        password = data.get("password") or ""
        conn = connect()
        row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        conn.close()
        if not row:
            recent.append(time.time())
            return self.send_json(401, {"ok": False, "message": "E-mail ou senha incorretos."})
        _, digest = hash_password(password, row["salt"])
        if not hmac.compare_digest(digest, row["password_hash"]):
            recent.append(time.time())
            return self.send_json(401, {"ok": False, "message": "E-mail ou senha incorretos."})
        self.send_json(200, {"ok": True, "token": make_token(row["id"]), "email": email})

    def forgot(self):
        data = self.read_json()
        email = (data.get("email") or "").strip().lower()
        conn = connect()
        row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        if not row:
            conn.close()
            return self.send_json(200, {"ok": True, "message": "Se a conta existir, o próximo passo foi preparado."})
        token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        conn.execute(
            "INSERT INTO password_resets (user_id, token_hash, expires_at, used) VALUES (?, ?, ?, 0)",
            (row["id"], token_hash, now() + 3600),
        )
        conn.commit()
        conn.close()
        reset_url = f"/#reset?token={token}"
        if get("SMTP_HOST") and get("SMTP_FROM"):
            try:
                send_reset_email(email, reset_url)
                return self.send_json(200, {"ok": True, "message": "E-mail de recuperação enviado."})
            except Exception as exc:
                return self.send_json(502, {"ok": False, "message": f"Não foi possível enviar o e-mail: {exc}"})
        payload = not_configured(
            ["SMTP_HOST", "SMTP_FROM"],
            "arquivo .env do servidor, campos SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM",
        )
        payload["message"] = "FUNÇÃO NÃO CONFIGURADA: o e-mail não foi enviado."
        if get("ALLOW_DEV_RESET_LINK") == "1":
            payload["dev_reset_url"] = reset_url
            payload["dev_note"] = "ALLOW_DEV_RESET_LINK=1 só para teste local. Desligue em produção."
        self.send_json(200, payload)

    def reset_password(self):
        data = self.read_json()
        token = data.get("token") or ""
        password = data.get("password") or ""
        if len(password) < 8:
            return self.send_json(400, {"ok": False, "message": "Senha com 8 ou mais caracteres."})
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        conn = connect()
        row = conn.execute(
            "SELECT * FROM password_resets WHERE token_hash = ? AND used = 0 AND expires_at > ?",
            (token_hash, now()),
        ).fetchone()
        if not row:
            conn.close()
            return self.send_json(400, {"ok": False, "message": "Link inválido ou vencido."})
        salt, digest = hash_password(password)
        conn.execute("UPDATE users SET password_hash = ?, salt = ? WHERE id = ?", (digest, salt, row["user_id"]))
        conn.execute("UPDATE password_resets SET used = 1 WHERE id = ?", (row["id"],))
        conn.commit()
        conn.close()
        self.send_json(200, {"ok": True, "message": "Senha trocada. Entre de novo."})

    def me(self):
        uid = self.user_id()
        if not uid:
            return self.send_json(401, {"ok": False})
        conn = connect()
        row = conn.execute("SELECT email FROM users WHERE id = ?", (uid,)).fetchone()
        conn.close()
        self.send_json(200, {"ok": True, "email": row["email"] if row else ""})

    def catalog(self, uid, query):
        section = (query.get("section") or ["mais_vendidos"])[0]
        page = int((query.get("page") or ["1"])[0])
        if section not in shopee.SECTIONS:
            return self.send_json(400, {"ok": False, "message": "Lista desconhecida."})
        miss = shopee.missing()
        if miss:
            return self.send_json(200, {**not_configured(miss, "Configurações > Shopee, ou .env: SHOPEE_APP_ID e SHOPEE_SECRET"), "products": [], "title": shopee.SECTIONS[section]["title"], "note": shopee.SECTIONS[section]["note"]})
        conn = connect()
        cached = conn.execute(
            "SELECT payload, fetched_at FROM product_cache WHERE section = ? AND page = ?",
            (section, page),
        ).fetchone()
        if cached and now() - cached["fetched_at"] < 60 * 60 * 6:
            conn.close()
            return self.send_json(200, {"ok": True, "cached": True, **json.loads(cached["payload"])})
        try:
            payload = shopee.fetch_section(section, page)
        except Exception as exc:
            conn.close()
            return self.send_json(502, {"ok": False, "message": "Não conseguimos atualizar os produtos agora. Tente novamente.", "detail": str(exc)})
        conn.execute(
            "INSERT OR REPLACE INTO product_cache (section, page, payload, fetched_at) VALUES (?, ?, ?, ?)",
            (section, page, json.dumps(payload), now()),
        )
        conn.commit()
        conn.close()
        self.send_json(200, {"ok": True, "cached": False, **payload})

    def refresh(self, uid, query):
        miss = shopee.missing()
        if miss:
            return self.send_json(200, not_configured(miss, "Configurações > Shopee"))
        section = (query.get("section") or ["mais_vendidos"])[0]
        try:
            payload = shopee.fetch_section(section, 1)
        except Exception as exc:
            return self.send_json(502, {"ok": False, "message": "Não conseguimos atualizar os produtos agora. Tente novamente.", "detail": str(exc)})
        conn = connect()
        conn.execute(
            "INSERT OR REPLACE INTO product_cache (section, page, payload, fetched_at) VALUES (?, 1, ?, ?)",
            (section, json.dumps(payload), now()),
        )
        conn.commit()
        conn.close()
        self.send_json(200, {"ok": True, **payload})

    def product(self, item_id):
        product = find_product(item_id)
        if not product:
            return self.send_json(404, {"ok": False, "message": "Produto não está no catálogo atual. Atualize a Shopee."})
        self.send_json(200, {"ok": True, "product": product})

    def product_link(self, item_id):
        product = find_product(item_id)
        if not product:
            return self.send_json(404, {"ok": False, "message": "Produto não encontrado no catálogo real."})
        link = product.get("offerLink") or product.get("productLink")
        if not link:
            return self.send_json(502, {"ok": False, "message": "A API não enviou link deste produto."})
        if shopee.missing():
            return self.send_json(200, {"ok": True, "url": link, "kind": "productLink"})
        try:
            link = shopee.short_link(link)
            kind = "shortLink"
        except Exception:
            kind = "offerLink" if product.get("offerLink") else "productLink"
            link = product.get("offerLink") or product.get("productLink")
        self.send_json(200, {"ok": True, "url": link, "kind": kind})

    def create_video(self, uid):
        data = self.read_json()
        return self.queue_video(uid, data.get("itemId"))

    def regenerate_video(self, uid, video_id):
        conn = connect()
        row = conn.execute("SELECT item_id FROM videos WHERE id = ? AND user_id = ?", (video_id, uid)).fetchone()
        conn.close()
        if not row:
            return self.send_json(404, {"ok": False, "message": "Vídeo não encontrado."})
        return self.queue_video(uid, row["item_id"])

    def queue_video(self, uid, item_id):
        miss = video.missing()
        if miss:
            return self.send_json(200, {**not_configured(miss, "Configurações > Vídeo, ou .env: FAL_KEY ou RUNWAY_API_KEY e VIDEO_PROVIDER"), "warning": "Nenhum vídeo foi gerado."})
        product = find_product(item_id)
        if not product:
            return self.send_json(404, {"ok": False, "message": "Produto não encontrado. Não geramos vídeo sem produto real."})
        if not product.get("imageUrl"):
            return self.send_json(422, {"ok": False, "message": "A API não enviou foto. Sem foto real o vídeo não é gerado."})
        limit = limits_for(uid)
        if limit["remaining"] == 0:
            return self.send_json(429, {"ok": False, "message": "Limite diário configurado foi atingido.", "limits": limit})
        prompt = video.build_prompt(product)
        conn = connect()
        cur = conn.execute(
            "INSERT INTO videos (user_id, item_id, product_name, status, provider, prompt, warning, created_at) VALUES (?, ?, ?, 'gerando', ?, ?, ?, ?)",
            (uid, item_id, product["name"], video.active(), prompt, "O modelo não garante preservação total do produto. O prompt pede para não alterar forma, logo, cor e embalagem.", now()),
        )
        conn.commit()
        vid = cur.lastrowid
        conn.close()
        threading.Thread(target=run_video_job, args=(vid, prompt, product["imageUrl"]), daemon=True).start()
        self.send_json(200, {"ok": True, "id": vid, "status": "gerando", "message": "Gerando vídeo...", "prompt": prompt})

    def videos(self, uid):
        conn = connect()
        rows = conn.execute(
            "SELECT id, item_id, product_name, status, provider, error, warning, created_at FROM videos WHERE user_id = ? ORDER BY id DESC",
            (uid,),
        ).fetchall()
        conn.close()
        self.send_json(200, {"ok": True, "videos": [dict(r) for r in rows], "limits": limits_for(uid)})

    def one_video(self, uid, video_id):
        conn = connect()
        row = conn.execute("SELECT * FROM videos WHERE id = ? AND user_id = ?", (video_id, uid)).fetchone()
        conn.close()
        if not row:
            return self.send_json(404, {"ok": False, "message": "Vídeo não encontrado."})
        data = dict(row)
        data.pop("file_path", None)
        if row["status"] == "pronto":
            data["url"] = f"/api/videos/{video_id}/file"
        self.send_json(200, {"ok": True, "video": data})

    def video_file(self, uid, video_id):
        conn = connect()
        row = conn.execute("SELECT file_path FROM videos WHERE id = ? AND user_id = ?", (video_id, uid)).fetchone()
        conn.close()
        if not row or not row["file_path"] or not Path(row["file_path"]).is_file():
            return self.send_json(404, {"ok": False, "message": "Arquivo de vídeo não existe."})
        data = Path(row["file_path"]).read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "video/mp4")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Content-Disposition", f'attachment; filename="lua-{video_id}.mp4"')
        self.end_headers()
        self.wfile.write(data)

    def delete_video(self, uid, video_id):
        conn = connect()
        row = conn.execute("SELECT file_path FROM videos WHERE id = ? AND user_id = ?", (video_id, uid)).fetchone()
        if not row:
            conn.close()
            return self.send_json(404, {"ok": False, "message": "Vídeo não encontrado."})
        if row["file_path"]:
            Path(row["file_path"]).unlink(missing_ok=True)
        conn.execute("DELETE FROM videos WHERE id = ? AND user_id = ?", (video_id, uid))
        conn.commit()
        conn.close()
        self.send_json(200, {"ok": True})

    def create_carousel(self, uid):
        data = self.read_json()
        product = find_product(data.get("itemId"))
        if not product:
            return self.send_json(404, {"ok": False, "message": "Escolha um produto real do catálogo. Sem Shopee conectada não há carrossel."})
        folder = STORAGE / "carousels" / f"{uid}-{int(time.time())}"
        try:
            files = carousel.build(product, folder)
        except Exception as exc:
            return self.send_json(502, {"ok": False, "message": "Não foi possível criar o carrossel.", "detail": str(exc)})
        conn = connect()
        cur = conn.execute(
            "INSERT INTO carousels (user_id, item_id, product_name, slides, created_at) VALUES (?, ?, ?, ?, ?)",
            (uid, product["itemId"], product["name"], json.dumps({"folder": str(folder), "files": files}), now()),
        )
        conn.commit()
        cid = cur.lastrowid
        conn.close()
        self.send_json(200, {"ok": True, "id": cid, "slides": [f"/api/carousels/{cid}/slide/{i}" for i in range(1, 6)]})

    def carousels(self, uid):
        conn = connect()
        rows = conn.execute(
            "SELECT id, item_id, product_name, created_at FROM carousels WHERE user_id = ? ORDER BY id DESC",
            (uid,),
        ).fetchall()
        conn.close()
        self.send_json(200, {"ok": True, "carousels": [dict(r) for r in rows]})

    def slide_file(self, uid, carousel_id, index):
        conn = connect()
        row = conn.execute("SELECT slides FROM carousels WHERE id = ? AND user_id = ?", (carousel_id, uid)).fetchone()
        conn.close()
        if not row:
            return self.send_json(404, {"ok": False, "message": "Carrossel não encontrado."})
        meta = json.loads(row["slides"])
        path = Path(meta["folder"]) / f"slide-{index}.png"
        if not path.is_file():
            return self.send_json(404, {"ok": False, "message": "Slide não encontrado."})
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "image/png")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Content-Disposition", f'attachment; filename="lua-slide-{index}.png"')
        self.end_headers()
        self.wfile.write(data)

    def delete_carousel(self, uid, carousel_id):
        conn = connect()
        row = conn.execute("SELECT slides FROM carousels WHERE id = ? AND user_id = ?", (carousel_id, uid)).fetchone()
        if not row:
            conn.close()
            return self.send_json(404, {"ok": False, "message": "Carrossel não encontrado."})
        folder = Path(json.loads(row["slides"])["folder"])
        for file in folder.glob("*"):
            file.unlink(missing_ok=True)
        folder.rmdir()
        conn.execute("DELETE FROM carousels WHERE id = ?", (carousel_id,))
        conn.commit()
        conn.close()
        self.send_json(200, {"ok": True})

    def create_post(self, uid):
        data = self.read_json()
        product = find_product(data.get("itemId"))
        if not product:
            return self.send_json(404, {"ok": False, "message": "Escolha um produto real. Sem catálogo não criamos post."})
        platform = data.get("platform") or "instagram"
        source = "openai"
        try:
            if ai.missing():
                raise RuntimeError("sem chave")
            text = ai.chat(
                [
                    {"role": "system", "content": "Escreva em português simples. Use só os fatos enviados. Se um dado estiver ausente, escreva 'não informado'. Não invente benefício."},
                    {"role": "user", "content": f"Plataforma: {platform}\n{ai.product_facts(product)}\nSepare legenda e hashtags com a linha ---"},
                ]
            )
            caption, _, tags = text.partition("---")
        except Exception:
            source = "dados_reais_sem_ia"
            caption = (
                f"{product['name']}\n\n"
                f"Preço informado: {product.get('priceMin')}\n"
                f"Desconto informado: {product.get('discountRate') if product.get('discountRate') not in (None, '') else 'não informado'}\n"
                f"Vendas informadas: {product.get('sales') if product.get('sales') is not None else 'não informado'}\n"
                f"Loja: {product.get('shopName') or 'não informada'}\n\n"
                "Veja o produto na Shopee pelo link real."
            )
            tags = "#shopee #oferta"
            if ai.missing():
                source = "dados_reais_sem_ia"
        conn = connect()
        cur = conn.execute(
            "INSERT INTO posts (user_id, item_id, product_name, platform, caption, hashtags, source, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (uid, product["itemId"], product["name"], platform, caption.strip(), tags.strip(), source, now()),
        )
        conn.commit()
        pid = cur.lastrowid
        conn.close()
        self.send_json(200, {"ok": True, "id": pid, "caption": caption.strip(), "hashtags": tags.strip(), "source": source, "ai_missing": ai.missing()})

    def posts(self, uid):
        conn = connect()
        rows = conn.execute(
            "SELECT id, product_name, platform, caption, hashtags, source, created_at FROM posts WHERE user_id = ? ORDER BY id DESC",
            (uid,),
        ).fetchall()
        conn.close()
        self.send_json(200, {"ok": True, "posts": [dict(r) for r in rows]})

    def assistant(self, uid):
        data = self.read_json()
        text = (data.get("text") or "").strip()
        if not text:
            return self.send_json(400, {"ok": False, "message": "Escreva ou fale alguma coisa."})
        if ai.missing():
            return self.send_json(200, {**not_configured(ai.missing(), "Configurações > IA, ou .env: OPENAI_API_KEY"), "reply": None})
        product = find_product(data.get("itemId")) if data.get("itemId") else None
        facts = ai.product_facts(product) if product else "Nenhum produto selecionado."
        try:
            reply = ai.chat(
                [
                    {"role": "system", "content": "Você é LUA, assistente simples de conteúdo para Shopee. Fale português fácil. Não invente preço, venda, link ou característica. Se faltar dado, diga que não está disponível."},
                    {"role": "user", "content": f"{facts}\n\nPergunta: {text}"},
                ]
            )
        except Exception as exc:
            return self.send_json(502, {"ok": False, "message": "Serviço temporariamente indisponível.", "detail": str(exc)})
        self.send_json(200, {"ok": True, "reply": reply})

    def save_integrations(self):
        data = self.read_json()
        allowed = ["SHOPEE_APP_ID", "SHOPEE_SECRET", "SHOPEE_SUB_ID", "OPENAI_API_KEY", "OPENAI_MODEL", "VIDEO_PROVIDER", "FAL_KEY", "RUNWAY_API_KEY", "VIDEO_DAILY_LIMIT", "SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASSWORD", "SMTP_FROM"]
        current = load_secrets()
        for key in allowed:
            value = data.get(key)
            if value is None or value == "":
                continue
            current[key] = str(value).strip()
        save_secrets(current)
        self.send_json(200, {"ok": True, "message": "Salvo no servidor. Os valores não voltam para a tela."})

    def test_shopee(self):
        miss = shopee.missing()
        if miss:
            return self.send_json(200, not_configured(miss, "Configurações > Shopee"))
        try:
            payload = shopee.fetch_section("mais_vendidos", 1)
        except Exception as exc:
            return self.send_json(502, {"ok": False, "message": "Não conseguimos atualizar os produtos agora. Tente novamente.", "detail": str(exc)})
        self.send_json(200, {"ok": True, "count": len(payload["products"]), "message": "Shopee respondeu."})

    def test_ai(self):
        if ai.missing():
            return self.send_json(200, not_configured(ai.missing(), "Configurações > IA"))
        try:
            reply = ai.chat([{"role": "user", "content": "Responda só: ok"}], max_tokens=10)
        except Exception as exc:
            return self.send_json(502, {"ok": False, "message": "Serviço temporariamente indisponível.", "detail": str(exc)})
        self.send_json(200, {"ok": True, "message": "IA respondeu.", "sample": reply[:80]})

    def proxy_image(self, query):
        url = (query.get("url") or [""])[0]
        host = urlparse(url).hostname or ""
        if not host.endswith(("shopee.com.br", "susercontent.com", "shopee.com")):
            return self.send_json(400, {"ok": False, "message": "Imagem fora da Shopee bloqueada."})
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "LUA/1.0"})
            with urllib.request.urlopen(req, timeout=20) as res:
                data = res.read()
                ctype = res.headers.get("Content-Type", "image/jpeg")
        except Exception:
            return self.send_json(502, {"ok": False, "message": "Não foi possível carregar a foto."})
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def find_product(item_id):
    if not item_id:
        return None
    conn = connect()
    rows = conn.execute("SELECT payload FROM product_cache").fetchall()
    conn.close()
    for row in rows:
        for product in json.loads(row["payload"]).get("products", []):
            if str(product.get("itemId")) == str(item_id):
                return product
    return None


def limits_for(uid):
    raw = get("VIDEO_DAILY_LIMIT")
    conn = connect()
    start = now() - (now() % 86400)
    used = conn.execute(
        "SELECT COUNT(*) AS n FROM videos WHERE user_id = ? AND created_at >= ? AND status != 'erro'",
        (uid, start),
    ).fetchone()["n"]
    conn.close()
    if not raw:
        return {"limit": None, "used": used, "remaining": None, "note": "O provedor não informou cota diária. Defina VIDEO_DAILY_LIMIT só com o número real do painel."}
    limit = int(raw)
    return {"limit": limit, "used": used, "remaining": max(0, limit - used), "note": "Limite definido por você em VIDEO_DAILY_LIMIT."}


def settings_view():
    keys = ["SHOPEE_APP_ID", "SHOPEE_SECRET", "SHOPEE_SUB_ID", "OPENAI_API_KEY", "OPENAI_MODEL", "VIDEO_PROVIDER", "FAL_KEY", "RUNWAY_API_KEY", "VIDEO_DAILY_LIMIT", "SMTP_HOST", "SMTP_FROM"]
    return {"ok": True, "fields": {key: {"set": bool(get(key)), "secret": key.endswith(("SECRET", "KEY", "PASSWORD"))} for key in keys}, "video_provider": video.active()}


def status_payload():
    return {
        "ok": True,
        "shopee": "conectado" if not shopee.missing() else "desconectado",
        "shopee_missing": shopee.missing(),
        "ia": "funcionando" if not ai.missing() else "indisponivel",
        "ia_missing": ai.missing(),
        "videos": "funcionando" if not video.missing() else "indisponivel",
        "videos_missing": video.missing(),
        "armazenamento": "funcionando" if STORAGE.exists() else "indisponivel",
        "banco": "funcionando",
    }


def send_reset_email(email, reset_url):
    msg = EmailMessage()
    msg["Subject"] = "LUA — nova senha"
    msg["From"] = get("SMTP_FROM")
    msg["To"] = email
    msg.set_content(f"Abra este caminho no app LUA e troque a senha:\n{reset_url}\n")
    with smtplib.SMTP(get("SMTP_HOST"), int(get("SMTP_PORT") or 587), timeout=20) as smtp:
        smtp.starttls()
        if get("SMTP_USER"):
            smtp.login(get("SMTP_USER"), get("SMTP_PASSWORD"))
        smtp.send_message(msg)


def run_video_job(video_id, prompt, image_url):
    conn = connect()
    try:
        remote, provider = video.generate(prompt, image_url)
        req = urllib.request.Request(remote, headers={"User-Agent": "LUA/1.0"})
        with urllib.request.urlopen(req, timeout=120) as res:
            data = res.read()
        if len(data) < 1000:
            raise RuntimeError("O arquivo baixado não parece um vídeo.")
        path = STORAGE / "videos" / f"{video_id}.mp4"
        path.write_bytes(data)
        conn.execute(
            "UPDATE videos SET status = 'pronto', file_path = ?, provider = ? WHERE id = ?",
            (str(path), provider, video_id),
        )
    except Exception as exc:
        conn.execute("UPDATE videos SET status = 'erro', error = ? WHERE id = ?", (str(exc)[:500], video_id))
    conn.commit()
    conn.close()


def daily_refresh():
    while True:
        time.sleep(3600)
        if shopee.missing():
            continue
        try:
            payload = shopee.fetch_section("mais_vendidos", 1)
            conn = connect()
            conn.execute(
                "INSERT OR REPLACE INTO product_cache (section, page, payload, fetched_at) VALUES ('mais_vendidos', 1, ?, ?)",
                (json.dumps(payload), now()),
            )
            conn.commit()
            conn.close()
        except Exception:
            pass


def main():
    threading.Thread(target=daily_refresh, daemon=True).start()
    host = get("SOL_HOST") or "0.0.0.0"
    port = int(get("SOL_PORT") or 8787)
    server = ThreadingHTTPServer((host, port), Handler)
    print(f"LUA em http://{host}:{port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
