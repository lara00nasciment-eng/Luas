import hashlib
import hmac
import json
import time
import urllib.error
import urllib.request
from app.config import get

ENDPOINT = "https://open-api.affiliate.shopee.com.br/graphql"
TIMEOUT = 25

SECTIONS = {
    "mais_vendidos": {
        "title": "MAIS VENDIDOS AGORA",
        "note": "Ordenado por vendidos (sortType 2) na API de afiliados da Shopee. O número de vendas é o campo sales, quando a API envia.",
        "listType": 0,
        "sortType": 2,
    },
    "em_alta": {
        "title": "EM ALTA",
        "note": "Lista Top performance (listType 2) da API de afiliados. Não é uma métrica independente de tendência.",
        "listType": 2,
        "sortType": 2,
    },
    "virais": {
        "title": "VIRAIS",
        "note": "A API oficial de afiliados não tem campo viral. Esta lista é Top performance (listType 2). O LUA não afirma que estes produtos são virais.",
        "listType": 2,
        "sortType": 1,
    },
    "oportunidades": {
        "title": "OPORTUNIDADES",
        "note": "Ordenado por comissão (sortType 5). Desconto só aparece se a API enviar priceDiscountRate. Preço anterior não existe nesta API e não é inventado.",
        "listType": 1,
        "sortType": 5,
    },
}

QUERY = """
query ($listType: Int, $sortType: Int, $page: Int, $limit: Int, $keyword: String) {
  productOfferV2(listType: $listType, sortType: $sortType, page: $page, limit: $limit, keyword: $keyword) {
    nodes {
      itemId
      productName
      productLink
      offerLink
      imageUrl
      priceMin
      priceMax
      priceDiscountRate
      sales
      ratingStar
      commissionRate
      sellerCommissionRate
      shopeeCommissionRate
      commission
      shopId
      shopName
      shopType
    }
    pageInfo { page limit hasNextPage }
  }
}
"""


def missing():
    need = []
    if not get("SHOPEE_APP_ID"):
        need.append("SHOPEE_APP_ID")
    if not get("SHOPEE_SECRET"):
        need.append("SHOPEE_SECRET")
    return need


def sign_and_post(payload_obj):
    app_id = get("SHOPEE_APP_ID")
    secret = get("SHOPEE_SECRET")
    payload = json.dumps(payload_obj, separators=(",", ":"), ensure_ascii=False)
    timestamp = str(int(time.time()))
    signature = hashlib.sha256(f"{app_id}{timestamp}{payload}{secret}".encode()).hexdigest()
    req = urllib.request.Request(
        ENDPOINT,
        data=payload.encode(),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"SHA256 Credential={app_id}, Timestamp={timestamp}, Signature={signature}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as res:
            raw = res.read().decode()
    except urllib.error.HTTPError as exc:
        body = exc.read().decode(errors="replace")
        raise RuntimeError(f"Shopee respondeu HTTP {exc.code}: {body[:400]}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError("Verifique sua conexão. A API da Shopee não respondeu.") from exc
    data = json.loads(raw)
    if data.get("errors"):
        raise RuntimeError(data["errors"][0].get("message", "Erro da API Shopee"))
    return data


def fetch_section(section, page=1, keyword=None):
    spec = SECTIONS[section]
    variables = {
        "listType": spec["listType"],
        "sortType": spec["sortType"],
        "page": page,
        "limit": 20,
    }
    if keyword:
        variables["keyword"] = keyword
    data = sign_and_post({"query": QUERY, "variables": variables})
    block = (data.get("data") or {}).get("productOfferV2") or {}
    nodes = block.get("nodes") or []
    products = [normalize(node) for node in nodes if node.get("itemId") and node.get("productName")]
    return {
        "section": section,
        "title": spec["title"],
        "note": spec["note"],
        "products": products,
        "pageInfo": block.get("pageInfo") or {"page": page, "limit": 20, "hasNextPage": False},
        "source": ENDPOINT,
    }


def normalize(node):
    price_min = node.get("priceMin")
    price_max = node.get("priceMax")
    discount = node.get("priceDiscountRate")
    return {
        "itemId": str(node.get("itemId")),
        "name": node.get("productName"),
        "imageUrl": node.get("imageUrl") or "",
        "priceMin": price_min,
        "priceMax": price_max,
        "pricePrevious": None,
        "pricePreviousNote": "A API de afiliados da Shopee não envia preço anterior.",
        "discountRate": discount,
        "sales": node.get("sales"),
        "rating": node.get("ratingStar"),
        "category": None,
        "categoryNote": "A consulta productOfferV2 não envia categoria.",
        "description": None,
        "descriptionNote": "A consulta productOfferV2 não envia descrição longa.",
        "productLink": node.get("productLink") or "",
        "offerLink": node.get("offerLink") or "",
        "commissionRate": node.get("commissionRate"),
        "shopName": node.get("shopName") or "",
        "shopId": node.get("shopId"),
    }


def short_link(origin_url):
    sub = get("SHOPEE_SUB_ID") or "lua"
    query = """
    mutation ($url: String!, $subIds: [String!]) {
      generateShortLink(input: {originUrl: $url, subIds: $subIds}) {
        shortLink
      }
    }
    """
    data = sign_and_post({"query": query, "variables": {"url": origin_url, "subIds": [sub]}})
    link = ((data.get("data") or {}).get("generateShortLink") or {}).get("shortLink")
    if not link:
        raise RuntimeError("A Shopee não devolveu shortLink.")
    return link
