import json
import urllib.error
import urllib.request
from app.config import get

PROVIDERS = ("fal", "runway")


def active():
    return (get("VIDEO_PROVIDER") or "fal").lower()


def missing():
    provider = active()
    if provider == "fal" and not get("FAL_KEY"):
        return ["FAL_KEY"]
    if provider == "runway" and not get("RUNWAY_API_KEY"):
        return ["RUNWAY_API_KEY"]
    if provider not in PROVIDERS:
        return [f"VIDEO_PROVIDER inválido: {provider}"]
    return []


def build_prompt(product):
    return (
        "Anime apenas a fotografia real deste produto para um anúncio curto. "
        "Preserve exatamente formato, embalagem, logotipo, marca, cor, quantidade e acessórios. "
        "Não troque o produto. Permitido: leve movimento de câmera, aproximação e cenário neutro. "
        f"Produto: {product.get('name')}. "
        f"Preço informado: {product.get('priceMin')}. "
        f"Loja: {product.get('shopName') or 'não informada'}."
    )


def generate(prompt, image_url):
    provider = active()
    if provider == "fal":
        return _fal(prompt, image_url), provider
    if provider == "runway":
        return _runway(prompt, image_url), provider
    raise RuntimeError("Provedor de vídeo não suportado.")


def _fal(prompt, image_url):
    body = json.dumps(
        {
            "prompt": prompt,
            "image_url": image_url,
            "duration": "5",
            "negative_prompt": "changed product, changed logo, changed color, changed packaging, extra items, deformed",
        }
    ).encode()
    req = urllib.request.Request(
        "https://fal.run/fal-ai/kling-video/v2.1/standard/image-to-video",
        data=body,
        headers={"Authorization": f"Key {get('FAL_KEY')}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as res:
            data = json.loads(res.read().decode())
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"fal.ai respondeu HTTP {exc.code}: {exc.read().decode(errors='replace')[:300]}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError("Verifique sua conexão. O fal.ai não respondeu.") from exc
    url = ((data.get("video") or {}).get("url")) or data.get("url")
    if not url:
        raise RuntimeError("fal.ai não devolveu URL de vídeo.")
    return url


def _runway(prompt, image_url):
    body = json.dumps(
        {
            "model": "gen4_turbo",
            "promptImage": image_url,
            "promptText": prompt[:1000],
            "ratio": "768:1280",
            "duration": 5,
        }
    ).encode()
    req = urllib.request.Request(
        "https://api.dev.runwayml.com/v1/image_to_video",
        data=body,
        headers={
            "Authorization": f"Bearer {get('RUNWAY_API_KEY')}",
            "X-Runway-Version": "2024-11-06",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=40) as res:
            task = json.loads(res.read().decode())
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"Runway respondeu HTTP {exc.code}: {exc.read().decode(errors='replace')[:300]}") from exc
    task_id = task.get("id")
    if not task_id:
        raise RuntimeError("Runway não devolveu id da tarefa.")
    for _ in range(40):
        import time
        time.sleep(4)
        poll = urllib.request.Request(
            f"https://api.dev.runwayml.com/v1/tasks/{task_id}",
            headers={
                "Authorization": f"Bearer {get('RUNWAY_API_KEY')}",
                "X-Runway-Version": "2024-11-06",
            },
        )
        with urllib.request.urlopen(poll, timeout=30) as res:
            status = json.loads(res.read().decode())
        if status.get("status") in ("SUCCEEDED", "succeeded"):
            output = status.get("output") or []
            if output:
                return output[0]
            raise RuntimeError("Runway concluiu sem arquivo.")
        if status.get("status") in ("FAILED", "failed", "CANCELLED"):
            raise RuntimeError(status.get("failure") or "Runway falhou ao gerar o vídeo.")
    raise RuntimeError("Tempo esgotado esperando a Runway.")
