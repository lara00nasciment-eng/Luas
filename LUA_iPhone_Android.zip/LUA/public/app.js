const state = { token: localStorage.getItem("lua_token") || "", email: "", screen: "home", product: null, section: "mais_vendidos", page: 1, busy: "" };

const $ = (id) => document.getElementById(id);
const app = $("app");

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (state.token) headers.Authorization = "Bearer " + state.token;
  if (options.body && !(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), options.timeout || 30000);
  try {
    const res = await fetch(path, { ...options, headers, signal: ctrl.signal });
    const data = await res.json().catch(() => ({ ok: false, message: "Resposta inválida." }));
    if (res.status === 401) { state.token = ""; localStorage.removeItem("lua_token"); render(); }
    return data;
  } catch (err) {
    if (err.name === "AbortError") return { ok: false, message: "Tempo esgotado. Tente novamente." };
    return { ok: false, message: "Verifique sua conexão." };
  } finally { clearTimeout(timer); }
}

function money(v) {
  if (v === null || v === undefined || v === "") return "não informado";
  const n = Number(v);
  if (Number.isNaN(n)) return String(v);
  return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function missingBox(data) {
  if (!data || data.code !== "NOT_CONFIGURED") return "";
  return `<div class="warn"><b>FUNÇÃO NÃO CONFIGURADA</b><p>Falta: ${(data.missing || []).join(", ")}</p><p>Onde colocar: ${data.where || "Configurações"}</p>${data.dev_reset_url ? `<p>Teste local: <a href="${data.dev_reset_url}">abrir troca de senha</a></p>` : ""}</div>`;
}

function setScreen(name) {
  state.screen = name;
  document.querySelectorAll("nav button").forEach((b) => b.classList.toggle("on", b.dataset.go === name));
  $("back").hidden = name === "home" || name === "login";
  render();
}

async function copy(text) {
  try {
    await navigator.clipboard.writeText(text);
    alert("Copiado.");
  } catch {
    alert("O navegador bloqueou a cópia. Selecione o texto e copie manualmente.");
  }
}

function productCard(p) {
  const img = p.imageUrl ? `/api/image?url=${encodeURIComponent(p.imageUrl)}` : "";
  return `<article class="card">
    ${img ? `<img src="${img}" alt="Foto do produto">` : `<p class="err">A API não enviou foto.</p>`}
    <p class="big">${p.name}</p>
    <p>${money(p.priceMin)}${p.priceMax && p.priceMax !== p.priceMin ? " a " + money(p.priceMax) : ""}</p>
    <p class="muted">Preço anterior: ${p.pricePreviousNote}</p>
    <p class="muted">Desconto: ${p.discountRate ?? "não informado"} · Vendas: ${p.sales ?? "não informado"}</p>
    <button data-open="${p.itemId}">VER PRODUTO</button>
  </article>`;
}

async function render() {
  if (!state.token && state.screen !== "reset") return authScreen();
  if (state.screen === "home") return home();
  if (state.screen === "catalog") return catalog();
  if (state.screen === "product") return productScreen();
  if (state.screen === "videos") return videos();
  if (state.screen === "carousels") return carousels();
  if (state.screen === "posts") return posts();
  if (state.screen === "lua") return assistant();
  if (state.screen === "settings") return settings();
  if (state.screen === "status") return status();
  if (state.screen === "reset") return resetScreen();
  home();
}

function authScreen() {
  app.innerHTML = `<p class="big">Entrar</p>
    <input id="email" type="email" placeholder="E-mail" autocomplete="username">
    <input id="pass" type="password" placeholder="Senha" autocomplete="current-password">
    <button id="login">ENTRAR</button>
    <button id="reg" class="dark">CRIAR CONTA</button>
    <button id="forgot" class="dark">ESQUECI A SENHA</button>
    <p id="msg" class="muted"></p>`;
  $("login").onclick = () => auth("/api/auth/login");
  $("reg").onclick = () => auth("/api/auth/register");
  $("forgot").onclick = forgot;
}

async function auth(path) {
  const data = await api(path, { method: "POST", body: JSON.stringify({ email: $("email").value, password: $("pass").value }) });
  if (!data.ok) return $("msg").textContent = data.message || "Erro.";
  state.token = data.token;
  localStorage.setItem("lua_token", data.token);
  state.email = data.email;
  setScreen("home");
}

async function forgot() {
  const data = await api("/api/auth/forgot", { method: "POST", body: JSON.stringify({ email: $("email").value }) });
  app.insertAdjacentHTML("beforeend", missingBox(data) + `<p class="muted">${data.message || ""}</p>`);
}

function home() {
  app.innerHTML = `<p class="big">O que você quer?</p>
    <button data-go="catalog">CATÁLOGO</button>
    <button data-go="videos">VÍDEOS</button>
    <button data-go="carousels">CARROSSÉIS</button>
    <button data-go="posts">POSTAGENS</button>
    <button data-go="lua">LUA — ASSISTENTE</button>
    <button data-go="status" class="dark">STATUS</button>`;
}

async function catalog() {
  app.innerHTML = `<p class="big">Buscando produtos...</p>`;
  const data = await api(`/api/catalog?section=${state.section}&page=${state.page}`);
  const buttons = ["mais_vendidos|MAIS VENDIDOS", "em_alta|EM ALTA", "virais|VIRAIS", "oportunidades|OPORTUNIDADES"]
    .map((x) => { const [id, label] = x.split("|"); return `<button class="dark" data-sec="${id}">${label}</button>`; }).join("");
  app.innerHTML = `<div class="row">${buttons}</div>
    <p class="big">${data.title || "Catálogo"}</p>
    <p class="muted">${data.note || ""}</p>
    ${missingBox(data)}
    ${data.message && data.code !== "NOT_CONFIGURED" ? `<p class="err">${data.message}</p><button id="retry">TENTAR NOVAMENTE</button>` : ""}
    <button id="refresh" class="dark">ATUALIZAR AGORA</button>
    <div id="list">${(data.products || []).map(productCard).join("") || (data.ok ? "<p>Nenhum produto nesta página.</p>" : "")}</div>
    <div class="row"><button id="prev" class="dark">ANTERIOR</button><button id="next">PRÓXIMA</button></div>`;
  document.querySelectorAll("[data-sec]").forEach((b) => b.onclick = () => { state.section = b.dataset.sec; state.page = 1; catalog(); });
  document.querySelectorAll("[data-open]").forEach((b) => b.onclick = () => openProduct(b.dataset.open));
  $("refresh").onclick = async () => { state.busy = "Atualizando..."; const r = await api(`/api/catalog/refresh?section=${state.section}`, { method: "POST" }); if (!r.ok && r.code !== "NOT_CONFIGURED") alert(r.message); catalog(); };
  $("retry") && ($("retry").onclick = catalog);
  $("prev").onclick = () => { if (state.page > 1) { state.page--; catalog(); } };
  $("next").onclick = () => { state.page++; catalog(); };
}

async function openProduct(id) {
  state.screen = "product";
  app.innerHTML = `<p class="big">Abrindo produto...</p>`;
  const data = await api("/api/products/" + id);
  if (!data.ok) { app.innerHTML = `<p class="err">${data.message}</p><button id="retry">TENTAR NOVAMENTE</button>`; $("retry").onclick = () => openProduct(id); return; }
  state.product = data.product;
  const p = data.product;
  const img = p.imageUrl ? `/api/image?url=${encodeURIComponent(p.imageUrl)}` : "";
  app.innerHTML = `<article class="card">
    ${img ? `<img src="${img}" alt="Foto real">` : ""}
    <p class="big">${p.name}</p>
    <p>Preço: ${money(p.priceMin)}</p>
    <p class="muted">${p.pricePreviousNote}</p>
    <p>Desconto: ${p.discountRate ?? "não informado"}</p>
    <p>Vendas: ${p.sales ?? "não informado"} · Nota: ${p.rating ?? "não informado"}</p>
    <p>Loja: ${p.shopName || "não informada"}</p>
    <p class="muted">${p.categoryNote}</p>
    <p class="muted">${p.descriptionNote}</p>
    <button id="shopee">VER NA SHOPEE</button>
    <button id="video">GERAR VÍDEO</button>
    <button id="car">CRIAR CARROSSEL</button>
    <button id="post">CRIAR POST</button>
  </article><p id="msg"></p>`;
  $("shopee").onclick = openShopee;
  $("video").onclick = () => makeVideo(p.itemId);
  $("car").onclick = () => makeCarousel(p.itemId);
  $("post").onclick = () => { state.product = p; setScreen("posts"); };
}

async function openShopee() {
  $("msg").textContent = "Buscando link real...";
  const data = await api(`/api/products/${state.product.itemId}/link`, { method: "POST", body: "{}" });
  if (!data.ok || !data.url) { $("msg").textContent = data.message || "Link não disponível."; return; }
  window.open(data.url, "_blank", "noopener");
  $("msg").textContent = "Link aberto: " + data.kind;
}

async function makeVideo(itemId) {
  app.innerHTML = `<p class="big">Gerando vídeo...</p><p class="muted">Isso só aparece enquanto a geração real está na fila.</p>`;
  const data = await api("/api/videos", { method: "POST", body: JSON.stringify({ itemId }), timeout: 20000 });
  if (data.code === "NOT_CONFIGURED") { app.innerHTML = missingBox(data); return; }
  if (!data.ok) { app.innerHTML = `<p class="err">${data.message || "Não foi possível gerar o vídeo. Tente novamente."}</p><button id="retry">TENTAR NOVAMENTE</button>`; $("retry").onclick = () => makeVideo(itemId); return; }
  pollVideo(data.id);
}

async function pollVideo(id) {
  const data = await api("/api/videos/" + id);
  const v = data.video;
  if (!v) return app.innerHTML = `<p class="err">Vídeo não encontrado.</p>`;
  if (v.status === "gerando") {
    app.innerHTML = `<p class="big">Preparando seu vídeo...</p><p class="muted">${v.warning || ""}</p>`;
    setTimeout(() => pollVideo(id), 4000);
    return;
  }
  if (v.status === "erro") {
    app.innerHTML = `<p class="err">Não foi possível gerar o vídeo. Tente novamente.</p><p class="muted">${v.error || ""}</p><button id="retry">TENTAR NOVAMENTE</button>`;
    $("retry").onclick = () => makeVideo(v.item_id);
    return;
  }
  app.innerHTML = `<p class="big">${v.product_name}</p>
    <video class="player" controls src="${v.url}"></video>
    <p class="warn">${v.warning || ""}</p>
    <button id="again">GERAR NOVAMENTE</button>
    <a href="${v.url}" download><button>SALVAR</button></a>
    <button id="share" class="dark">COMPARTILHAR</button>
    <button id="del" class="danger">EXCLUIR</button>`;
  $("again").onclick = () => makeVideo(v.item_id);
  $("share").onclick = () => share(location.origin + v.url, v.product_name);
  $("del").onclick = async () => { await api("/api/videos/" + id, { method: "DELETE" }); setScreen("videos"); };
}

async function videos() {
  app.innerHTML = `<p class="big">Meus vídeos</p><p>Carregando...</p>`;
  const data = await api("/api/videos");
  const lim = data.limits || {};
  const limitText = lim.limit == null ? lim.note : `Vídeos disponíveis hoje: ${lim.remaining}`;
  app.innerHTML = `<p class="big">MEUS VÍDEOS</p><p class="muted">${limitText || ""}</p>
    ${(data.videos || []).map((v) => `<article class="card"><p class="big">${v.product_name}</p><p>${new Date(v.created_at * 1000).toLocaleString("pt-BR")}</p><p>${v.status}</p><button data-watch="${v.id}">ASSISTIR</button><button class="danger" data-del="${v.id}">EXCLUIR</button></article>`).join("") || "<p>Nenhum vídeo ainda.</p>"}`;
  document.querySelectorAll("[data-watch]").forEach((b) => b.onclick = () => pollVideo(b.dataset.watch));
  document.querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => { await api("/api/videos/" + b.dataset.del, { method: "DELETE" }); videos(); });
}

async function makeCarousel(itemId) {
  app.innerHTML = `<p class="big">Criando carrossel...</p>`;
  const data = await api("/api/carousels", { method: "POST", body: JSON.stringify({ itemId }) });
  if (!data.ok) { app.innerHTML = `<p class="err">${data.message}</p>`; return; }
  showCarousel(data);
}

function showCarousel(data) {
  app.innerHTML = `<p class="big">Carrossel</p>
    ${(data.slides || []).map((s) => `<article class="card"><img src="${s}" alt="Slide"><a href="${s}" download><button>SALVAR IMAGEM</button></a></article>`).join("")}
    <button id="again">GERAR NOVAMENTE</button>`;
  $("again").onclick = () => makeCarousel(state.product.itemId);
}

async function carousels() {
  const data = await api("/api/carousels");
  app.innerHTML = `<p class="big">CARROSSÉIS</p><p class="muted">Escolha um produto no catálogo para criar.</p>
    ${(data.carousels || []).map((c) => `<article class="card"><p>${c.product_name}</p><button data-c="${c.id}">VER</button><button class="danger" data-del="${c.id}">EXCLUIR</button></article>`).join("") || "<p>Nenhum carrossel.</p>"}`;
  document.querySelectorAll("[data-c]").forEach((b) => b.onclick = () => showCarousel({ slides: [1, 2, 3, 4, 5].map((n) => `/api/carousels/${b.dataset.c}/slide/${n}`) }));
  document.querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => { await api("/api/carousels/" + b.dataset.del, { method: "DELETE" }); carousels(); });
}

async function posts() {
  app.innerHTML = `<p class="big">POSTAR</p>
    <p class="muted">${state.product ? state.product.name : "Abra um produto no catálogo primeiro."}</p>
    <button id="ig">CRIAR PARA INSTAGRAM</button>
    <button id="tk" class="dark">CRIAR PARA TIKTOK</button>
    <div id="out"></div>`;
  $("ig").onclick = () => makePost("instagram");
  $("tk").onclick = () => makePost("tiktok");
}

async function makePost(platform) {
  if (!state.product) { $("out").innerHTML = `<p class="err">Escolha um produto real no catálogo.</p>`; return; }
  $("out").innerHTML = `<p>Criando legenda...</p>`;
  const data = await api("/api/posts", { method: "POST", body: JSON.stringify({ itemId: state.product.itemId, platform }) });
  if (!data.ok) { $("out").innerHTML = `<p class="err">${data.message}</p>`; return; }
  $("out").innerHTML = `${data.source !== "openai" ? missingBox({ code: "NOT_CONFIGURED", missing: data.ai_missing, where: "Configurações > IA" }) + "<p class='muted'>Texto abaixo usa só dados reais do produto. Nenhum benefício foi inventado.</p>" : ""}
    <textarea id="cap">${data.caption}</textarea>
    <textarea id="tags">${data.hashtags}</textarea>
    <button id="c1">COPIAR LEGENDA</button>
    <button id="c2" class="dark">COPIAR HASHTAGS</button>
    <button id="c3" class="dark">COPIAR TUDO</button>`;
  $("c1").onclick = () => copy($("cap").value);
  $("c2").onclick = () => copy($("tags").value);
  $("c3").onclick = () => copy($("cap").value + "\n\n" + $("tags").value);
}

function assistant() {
  app.innerHTML = `<p class="big">LUA</p>
    <p class="muted">Pergunte sobre o produto aberto, legenda ou roteiro.</p>
    <textarea id="q" placeholder="Fale ou escreva"></textarea>
    <button id="mic">🎤 FALAR</button>
    <button id="send">ENVIAR</button>
    <div id="out"></div>`;
  $("send").onclick = ask;
  $("mic").onclick = listen;
}

function listen() {
  const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Rec) { $("out").innerHTML = `<p class="err">Este aparelho não tem reconhecimento de voz no navegador.</p>`; return; }
  const rec = new Rec();
  rec.lang = "pt-BR";
  rec.onresult = (e) => { $("q").value = e.results[0][0].transcript; ask(); };
  rec.onerror = () => { $("out").innerHTML = `<p class="err">Não foi possível ouvir. Verifique a permissão do microfone.</p>`; };
  rec.start();
}

async function ask() {
  $("out").innerHTML = `<p>LUA está pensando...</p>`;
  const data = await api("/api/assistant", { method: "POST", body: JSON.stringify({ text: $("q").value, itemId: state.product && state.product.itemId }) });
  if (data.code === "NOT_CONFIGURED") { $("out").innerHTML = missingBox(data); return; }
  if (!data.ok) { $("out").innerHTML = `<p class="err">${data.message}</p><button id="retry">TENTAR NOVAMENTE</button>`; $("retry").onclick = ask; return; }
  $("out").innerHTML = `<p class="card">${data.reply}</p><button id="speak" class="dark">OUVIR RESPOSTA</button>`;
  $("speak").onclick = () => {
    if (!window.speechSynthesis) return alert("Este aparelho não lê texto em voz alta.");
    speechSynthesis.speak(new SpeechSynthesisUtterance(data.reply));
  };
}

async function settings() {
  const data = await api("/api/settings");
  const fields = data.fields || {};
  const line = (key) => `<p>${key}: ${fields[key] && fields[key].set ? "<span class='ok'>configurado</span>" : "<span class='bad'>faltando</span>"}</p>`;
  app.innerHTML = `<p class="big">CONFIGURAÇÕES</p>
    <p>Conta: ${state.email || "conectada"}</p>
    <button id="out" class="dark">SAIR</button>
    <p class="big">Shopee</p>
    ${line("SHOPEE_APP_ID")}${line("SHOPEE_SECRET")}
    <input id="SHOPEE_APP_ID" placeholder="App ID">
    <input id="SHOPEE_SECRET" type="password" placeholder="Secret (não aparece depois)">
    <input id="SHOPEE_SUB_ID" placeholder="Sub ID de afiliado">
    <p class="big">IA</p>${line("OPENAI_API_KEY")}
    <input id="OPENAI_API_KEY" type="password" placeholder="OPENAI_API_KEY">
    <p class="big">Vídeo</p>${line("FAL_KEY")}${line("RUNWAY_API_KEY")}
    <select id="VIDEO_PROVIDER"><option value="fal">fal (Kling)</option><option value="runway">runway</option></select>
    <input id="FAL_KEY" type="password" placeholder="FAL_KEY">
    <input id="RUNWAY_API_KEY" type="password" placeholder="RUNWAY_API_KEY">
    <input id="VIDEO_DAILY_LIMIT" placeholder="Limite diário real, se souber">
    <button id="save">SALVAR</button>
    <button id="tshopee" class="dark">TESTAR SHOPEE</button>
    <button id="tai" class="dark">TESTAR IA</button>
    <button id="status" class="dark">VER STATUS</button>
    <div id="msg"></div>`;
  $("save").onclick = saveSettings;
  $("tshopee").onclick = async () => { $("msg").textContent = "Testando Shopee..."; const r = await api("/api/settings/test/shopee", { method: "POST", body: "{}" }); $("msg").innerHTML = missingBox(r) + `<p>${r.message || ""} ${r.detail || ""}</p>`; };
  $("tai").onclick = async () => { $("msg").textContent = "Testando IA..."; const r = await api("/api/settings/test/ai", { method: "POST", body: "{}" }); $("msg").innerHTML = missingBox(r) + `<p>${r.message || ""} ${r.detail || ""}</p>`; };
  $("status").onclick = () => setScreen("status");
  $("out").onclick = () => { localStorage.removeItem("lua_token"); state.token = ""; render(); };
}

async function saveSettings() {
  const body = {};
  ["SHOPEE_APP_ID", "SHOPEE_SECRET", "SHOPEE_SUB_ID", "OPENAI_API_KEY", "VIDEO_PROVIDER", "FAL_KEY", "RUNWAY_API_KEY", "VIDEO_DAILY_LIMIT"].forEach((k) => { if ($(k).value) body[k] = $(k).value; });
  const data = await api("/api/settings/integrations", { method: "POST", body: JSON.stringify(body) });
  $("msg").textContent = data.message || data.message;
  settings();
}

async function status() {
  const data = await api("/api/status");
  const mark = (v) => v === "conectado" || v === "funcionando" ? `<span class="ok">🟢 ${v}</span>` : `<span class="bad">🔴 ${v}</span>`;
  app.innerHTML = `<p class="big">STATUS</p>
    <p>Shopee: ${mark(data.shopee)}</p><p class="muted">${(data.shopee_missing || []).join(", ")}</p>
    <p>IA: ${mark(data.ia)}</p><p class="muted">${(data.ia_missing || []).join(", ")}</p>
    <p>Vídeos: ${mark(data.videos)}</p><p class="muted">${(data.videos_missing || []).join(", ")}</p>
    <p>Armazenamento: ${mark(data.armazenamento)}</p>
    <p>Banco: ${mark(data.banco)}</p>`;
}

function resetScreen() {
  const token = new URLSearchParams(location.hash.split("?")[1] || "").get("token") || "";
  app.innerHTML = `<p class="big">Nova senha</p><input id="pass" type="password" placeholder="Nova senha"><button id="go">TROCAR SENHA</button><p id="msg"></p>`;
  $("go").onclick = async () => {
    const data = await api("/api/auth/reset", { method: "POST", body: JSON.stringify({ token, password: $("pass").value }) });
    $("msg").textContent = data.message || "";
    if (data.ok) setTimeout(() => { state.screen = "login"; state.token = ""; render(); }, 800);
  };
}

async function share(url, title) {
  if (navigator.share) {
    try { await navigator.share({ title, url }); return; } catch {}
  }
  copy(url);
}

document.body.addEventListener("click", (e) => {
  const go = e.target.dataset && e.target.dataset.go;
  if (go) setScreen(go);
});
$("settings").onclick = () => setScreen("settings");
$("back").onclick = () => setScreen("home");
if (location.hash.startsWith("#reset")) state.screen = "reset";
api("/api/auth/me").then((d) => { if (d.ok) state.email = d.email; render(); });
