from app.config import load_env_file
from app.server import main

if __name__ == "__main__":
    load_env_file()
    main()
