import json
import os
import threading
import time
import urllib.error
import urllib.request

os.environ["SOL_PORT"] = "8791"
os.environ["ALLOW_DEV_RESET_LINK"] = "1"
os.environ["APP_SECRET"] = "teste-sol"

from app.server import Handler, main

def start():
    threading.Thread(target=main, daemon=True).start()
    time.sleep(0.4)

def call(path, payload=None, token=None, method=None):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request("http://127.0.0.1:8791" + path, data=data, method=method or ("POST" if payload is not None else "GET"))
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(req, timeout=10) as res:
            return json.loads(res.read().decode())
    except urllib.error.HTTPError as exc:
        return json.loads(exc.read().decode())

def main_test():
    start()
    email = f"sol{int(time.time())}@teste.com"
    reg = call("/api/auth/register", {"email": email, "password": "senha1234"})
    assert reg["ok"] and reg["token"], reg
    bad = call("/api/auth/login", {"email": email, "password": "errada"})
    assert bad["ok"] is False
    login = call("/api/auth/login", {"email": email, "password": "senha1234"})
    assert login["ok"]
    token = login["token"]
    forgot = call("/api/auth/forgot", {"email": email})
    assert forgot["code"] == "NOT_CONFIGURED" and "dev_reset_url" in forgot
    reset_token = forgot["dev_reset_url"].split("token=")[1]
    reset = call("/api/auth/reset", {"token": reset_token, "password": "senha9876"})
    assert reset["ok"], reset
    relog = call("/api/auth/login", {"email": email, "password": "senha9876"})
    assert relog["ok"]
    status = call("/api/status")
    assert status["shopee"] == "desconectado"
    assert status["videos"] == "indisponivel"
    catalog = call("/api/catalog?section=mais_vendidos", token=token)
    assert catalog["code"] == "NOT_CONFIGURED" and catalog["products"] == []
    video = call("/api/videos", {"itemId": "1"}, token=token)
    assert video["code"] == "NOT_CONFIGURED"
    car = call("/api/carousels", {"itemId": "1"}, token=token)
    assert car["ok"] is False
    assistant = call("/api/assistant", {"text": "oi"}, token=token)
    assert assistant["code"] == "NOT_CONFIGURED"
    me = call("/api/auth/me", token=token)
    assert me["email"] == email
    print("TESTES OK")

if __name__ == "__main__":
    main_test()
